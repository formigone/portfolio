-----------------------------------------------------------------

    Copyright (c) 2011 Rodrigo Silveira. All rights reserved.
                http://www.rodrigo-silveira.com

-----------------------------------------------------------------
-----------------------------------------------------------------


How to use this server:

The only assumption I'm making in order to simplify the following instructions, is that you are running this server locally, more specifically from a WAMP installation in C:/
For help on how to set up a WAMP server, or on how to run this server and application in case the following instructions aren't very clear, contact me at http://www.rodrigo-silveira.com/blog

1. To run the server, simply execute the commandline instruction >> php -q /wamp/www/cs460/websocket.html5server.cs460
2. Open the index.html file in a modern browser. Remember that the only browsers that fully support this implementation of the WebSocket API (along with some of the CSS3 and Javascript used throughout the client application) are Google Chrome, Google Chromium, and Safari. It is recommended that the latest versions are used for this.
3. Have fun, extend the application, and share what you learn with others!